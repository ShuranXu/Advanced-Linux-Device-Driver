#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>

/**
 Demonstrate the use of jprobe to dump kernel stack trace
 Using mmap driver routine mmap_kmalloc() as an example
*/

static int my_mmap_kmalloc (struct file * filp, struct vm_area_struct * vma)
{
	printk("mmap_kmalloc is called\n");
	//private_data field of file structure points to minor number
        printk("private_data field: %d\n", *(int*)filp->private_data);
        dump_stack();

        jprobe_return(); // required for jprobe

        return 0; // not reached
}

static int my_mmap_vmalloc (struct file * filp, struct vm_area_struct * vma)
{
        printk("mmap_vmalloc is called\n");
        //private_data field of file structure points to minor number
        printk("private_data field: minor= %d\n", *(int*)filp->private_data);
        dump_stack();

        jprobe_return(); // required for jprobe

        return 0; // not reached
}

	
static struct jprobe my_jprobe1 = {
        .entry = (kprobe_opcode_t *) my_mmap_kmalloc,
};

static struct jprobe my_jprobe2 = {
        .entry = (kprobe_opcode_t *) my_mmap_vmalloc,
};

int init_module(void)
{
	int ret;
        my_jprobe1.kp.addr = (kprobe_opcode_t *) kallsyms_lookup_name("mmap_kmalloc");
        my_jprobe2.kp.addr = (kprobe_opcode_t *) kallsyms_lookup_name("mmap_vmalloc");
       
       if (!my_jprobe1.kp.addr) {
               printk("Address %s is not found\n", "mmap_kmalloc");
               return -1;
        }

       if (!my_jprobe2.kp.addr) {
               printk("Address %s is not found\n", "mmap_vmalloc");
               return -1;
        }

       if ((ret = register_jprobe(&my_jprobe1)) <0) {
            printk("register_jprobe failed, returned %d\n", ret);
            return -1;
         }
       if ((ret = register_jprobe(&my_jprobe2)) <0) {
            printk("register_jprobe failed, returned %d\n", ret);
            return -1;
         }

        printk("jprobe is set at kernel addr: %p, Our handler addr %p\n", my_jprobe1.kp.addr, my_jprobe1.entry);
        printk("jprobe is set at kernel addr: %p, Our handler addr %p\n", my_jprobe2.kp.addr, my_jprobe2.entry);
        return 0;	
  
}

void cleanup_module(void)
{
        unregister_jprobe(&my_jprobe1);
        unregister_jprobe(&my_jprobe2);
        printk("jprobe unregistered\n");
}

MODULE_LICENSE("GPL");

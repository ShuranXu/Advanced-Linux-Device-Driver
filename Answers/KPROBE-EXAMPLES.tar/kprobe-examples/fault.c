#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>
#include <linux/sched.h>

/** 
 Example on how to use kprobe to dump cpu registers and other
 relevent information in the context of the probe function 
 In this example, we set a probe on mmap driver routine mmap_kmalloc()
*/

// One kprobe structure per probe
static struct kprobe kp1;

static void dump_state(struct pt_regs *regs)
{
/**
dump when probe is hit. If interested in printing function args, then use jprobe instead.
Also, use retprobe for return value.  With kprobe, you may need to know the registers where 
arguments (pt_regs) are passed and return value are saved...and that gets tricky if you don't 
know x86 assembly.  
x86-32: first 3 arguments are passed in eax, edx and ecx, and rest go on stack register on 
stack can be accessed using *(esp+4)- 4th argument, *(esp+8)- 5th argument, and so on.
x86-64: first 6 arguments in rdi, rsi, rdx, rcx, r8, r9.. the remaining ones go on stack.
 *(esp+8) - 7th argument, *(esp+16) - 8th and so on.
For x86-32, the value of esp is not saved in pt_regs for kernel-mode traps that includes the 
software breakpoints that kprobes rely upon.  There are generic functions (<asm/ptrace.h>) like 
kernel_stack_pointer() to access esp register. It works both on x86-32 x86-64.
Another function, regs_get_kernel_stack_nth() makes it easy to dump content of the stack in the handler.
*/
  printk("Process %s (pid: %d, threadinfo=%p task=%p)\n", current->comm, current->pid, current_thread_info(), current);
  printk("ip register (alias for eip on 32-bit and rip on 64-bit): %lx\n", regs->ip);
  printk("ax register (alias for eax on 32-bit and rax on 64-bit): %lx\n", regs->ax);
}

// kprobe pre handler
int handler_pre(struct kprobe *p, struct pt_regs *regs)
{
        printk("pre_handler: p->addr=0x%p\n\n", p->addr);
        dump_state(regs);  
        dump_stack();
        return 0;
}

// kprobe post handler
void handler_post(struct kprobe *p, struct pt_regs *regs, unsigned long flags)
{
        printk("post_handler: p->addr=0x%p\n", p->addr);
        dump_state(regs);
        return;
}

// fault_handler to deal with exception caused by our handlers. Do nothing..
int handler_fault(struct kprobe *p, struct pt_regs *regs, int trapnr)
{
        printk("fault_handler: p->addr=0x%p, trap #%dn",
                p->addr, trapnr);
        /* Return 0 because no handler to handle fault. */
        return 0;
}

int init_module(void)
{
        int ret;

        kp1.pre_handler = handler_pre;
        kp1.post_handler = handler_post;
        kp1.fault_handler = handler_fault;

        kp1.addr = (kprobe_opcode_t*) kallsyms_lookup_name("mmap_kmalloc");

        if (!kp1.addr) {
                printk("Address %s is not found\n", "mmap_kmalloc");
                return -1;
        }
        if ((ret = register_kprobe(&kp1) < 0)) {
                printk("register_kprobe failed, returned %d\n", ret);
                return -1;
        }
        printk("\nkprobe is set at kernel addr: %p, Our handlers: handler_pre: %p, handler_post: %p\n",
						 kp1.addr, kp1.pre_handler, kp1.post_handler);
        return 0;
}

void cleanup_module(void)
{
        unregister_kprobe(&kp1);
        printk("kprobe unregistered\n");
}

MODULE_LICENSE("GPL");

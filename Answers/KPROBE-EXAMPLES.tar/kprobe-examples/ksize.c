#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/kallsyms.h>

// Demonstrate the use jprobe and kretprob to print
// function arguments and return value
// Use __kmalloc() as an example


// jprobe
static int my_kmalloc (size_t size, gfp_t flags)
{
	printk("kmalloc is called: size: %lu by process: %s\n", size, current->comm);
        //dump_stack();

        jprobe_return(); // required for jprobe

        return 0; // not reached
}
	
static struct jprobe my_jprobe = {
        .entry = (kprobe_opcode_t *) my_kmalloc,
};

// kretprobe
static int ret_handler(struct kretprobe_instance *ri, struct pt_regs *regs)
 {
      long retval = regs_return_value(regs);  	     // more portable
      //printk("kmalloc returns %lx\n", regs->ax);   //register ax on x86 contains return value
      printk("kmalloc returns: %lx \n", retval); 
      return 0;
 }
 
static struct kretprobe my_kretprobe = {
        .handler = ret_handler,
	.maxactive = 20  // max 20 concurrent probes
 };

int init_module(void)
{
	int ret;
        my_jprobe.kp.addr = my_kretprobe.kp.addr =  (kprobe_opcode_t *) kallsyms_lookup_name("__kmalloc");
       
       if (!my_jprobe.kp.addr) {
               printk("Address %s is not found\n", "__kmalloc");
               return -1;
        }

       if ((ret = register_jprobe(&my_jprobe)) <0) {
            	printk("register_jprobe failed, returned %d\n", ret);
            	return -1;
         }

       
       if ((ret = register_kretprobe(&my_kretprobe)) < 0) {
        	printk("register_kretprobe failed, returned %d\n", ret);
        	unregister_jprobe(&my_jprobe);
         	return -1;
          }

        printk("jprobe is set at kernel addr: %p, Our handler addr %p\n", my_jprobe.kp.addr, my_jprobe.entry);
        printk("kretprobe is set at kernel addr: %p, Our handler addr %p\n", my_kretprobe.kp.addr, my_kretprobe.handler);
        return 0;	
  
}

void cleanup_module(void)
{
        unregister_jprobe(&my_jprobe);
	unregister_kretprobe(&my_kretprobe);
        printk("jprobe unregistered\n");
        printk("kretprobe unregistered\n");
}

MODULE_LICENSE("GPL");


#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/ktime.h>
#include <linux/limits.h>
#include <linux/sched.h>

/**
 Use of kretprobe entry and return handler to report kernel function timimg
 We use mmap driver routine mmap_kmalloc() and mmap_vmalloc() as an example
*/

// my_data is used to record time at function entry 
// We can then extract it from kretprobe structure passed as argument
// to our entry and and return handlers
struct my_data {
	ktime_t entry_stamp;
};

// kretprobe function entry handler
static int kfunc_enter(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct my_data *data;

	if (!current->mm)
		return 1;	/* Skip kernel threads */

	data = (struct my_data *)ri->data;
	data->entry_stamp = ktime_get();  // save timestamp
	return 0;
}

// kretprobe function return handler
static int kfunc_return(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	int retval = regs_return_value(regs);
	struct my_data *data = (struct my_data *)ri->data;
	s64 delta;
	ktime_t now;

	now = ktime_get();
	delta = ktime_to_ns(ktime_sub(now, data->entry_stamp));
	printk(KERN_INFO "%s returned %d and took %lld ns to execute\n", "mmap_kmalloc", retval, (long long)delta);
	return 0;
}

// kretprobe function entry handler
static int vfunc_enter(struct kretprobe_instance *ri, struct pt_regs *regs)
{
        struct my_data *data;

        if (!current->mm)
                return 1;       /* Skip kernel threads */

        data = (struct my_data *)ri->data;
        data->entry_stamp = ktime_get();  // save timestamp
        return 0;
}

// kretprobe function return handler
static int vfunc_return(struct kretprobe_instance *ri, struct pt_regs *regs)
{
        int retval = regs_return_value(regs);
        struct my_data *data = (struct my_data *)ri->data;
        s64 delta;
        ktime_t now;

        now = ktime_get();
        delta = ktime_to_ns(ktime_sub(now, data->entry_stamp));
        printk(KERN_INFO "%s returned %d and took %lld ns to execute\n", "mmap_kmalloc", retval, (long long)delta);
        return 0;
}

static struct kretprobe my_kretprobe1 = {
	.handler		= kfunc_return,
	.entry_handler		= kfunc_enter,
	.data_size		= sizeof(struct my_data),
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 20,
};

static struct kretprobe my_kretprobe2 = {
        .handler                = vfunc_return,
        .entry_handler          = vfunc_enter,
        .data_size              = sizeof(struct my_data),
        /* Probe up to 20 instances concurrently. */
        .maxactive              = 20,
};

static int __init kretprobe_init(void)
{
	int ret;

//      Set the probe point at our driver function "mmap_kmalloc"

	my_kretprobe1.kp.addr =  (kprobe_opcode_t *) kallsyms_lookup_name("mmap_kmalloc");
	my_kretprobe2.kp.addr =  (kprobe_opcode_t *) kallsyms_lookup_name("mmap_vmalloc");

	ret = register_kretprobe(&my_kretprobe1);
	if (ret < 0) {
		printk(KERN_INFO "register_kretprobe failed, returned %d\n", ret);
		return -1;
	}
 	ret = register_kretprobe(&my_kretprobe2);
        if (ret < 0) {
                printk(KERN_INFO "register_kretprobe failed, returned %d\n", ret);
                return -1;
        }

	printk(KERN_INFO "probe1 address: %p\n", my_kretprobe1.kp.addr);
	printk(KERN_INFO "probe2 address: %p\n", my_kretprobe2.kp.addr);
	return 0;
}

static void __exit kretprobe_exit(void)
{
	unregister_kretprobe(&my_kretprobe1);
	unregister_kretprobe(&my_kretprobe2);
	printk(KERN_INFO "kretprobe at %p unregistered\n", my_kretprobe1.kp.addr);
	printk(KERN_INFO "kretprobe at %p unregistered\n", my_kretprobe2.kp.addr);

}

module_init(kretprobe_init)
module_exit(kretprobe_exit)
MODULE_LICENSE("GPL");
